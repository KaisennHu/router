# C16, two-worker bounded-output AgentX case

Goal: evaluate Progress and end-to-end performance against cache-aware with a more available two-GPU topology. Two B300 TP1 workers, C16, 48 GiB HBM KV per worker, no host offload, max model 196608, max batched 8192, max 16 sequences/worker; Cache uses default 0.3/64/1.5 thresholds.

The same 32-session, four-request AgentX subset as the prior incomplete four-GPU case is used unchanged. Original outputs are positive and at most 1024 tokens, with no truncation. The seed-0 initial 16 sessions contain four long-first sessions, so the number of initial long prefills per worker equals two; other sessions have short first requests followed by 32768–65535 novel input tokens. The subset was selected from source structure, not performance outcomes.

Prespecified: one two-worker KV+P instrumented diagnostic, then Cache, KV, and KV+P without the diagnostic instrumentation, one successful run each on the same two GPUs. Report all results, including regressions, and verify actual cache-hit, new computation, preemption, queue, prefill, TTFT, TPOT, JCT, throughput, progress acceptance, other-user GPU interference, and Router KV-event errors. The earlier four-GPU diagnostic is preserved as separate evidence and must not be mixed with these results.

Same-agent gaps are scaled to zero and token IDs are reconstructed per session, so the subset is targeted and does not represent all AgentX traffic.
