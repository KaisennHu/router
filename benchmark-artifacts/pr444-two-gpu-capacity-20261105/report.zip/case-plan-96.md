# Two GPUs, C16: 96 GiB capacity control

Use the exact same 32-session bounded-output AgentX subset and GPUs 0/1 as the completed 48 GiB two-GPU comparison. Keep C16, model, vLLM, Router, batch size, cold-cache reset and policies unchanged; only the HBM KV budget changes from 48 to 96 GiB per worker. The goal is to test whether reduced capacity and cache reuse accompany the observed Progress regression, not to infer causality from one run.

Run one Cache, one KV and one KV+Progress production cell, each with no diagnostic instrumentation. Report all outcomes and trace assumptions; retain the earlier 48 GiB data even if this case looks better. Stop/retry only if another process uses a selected GPU.
