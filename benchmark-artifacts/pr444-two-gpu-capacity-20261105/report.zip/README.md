# Two-GPU AgentX capacity comparison

`REPORT.html` is self-contained and compares 48 and 96 GiB. `DIAGNOSIS.md` contains the separate 48 GiB instrumented request comparison. `REPORT-48.html` provides the detailed 48 GiB report. `aggregate.json` and `client/` contain sanitized aggregates and per-request/session metrics. The trace manifest records the original dataset, selected sessions and hash; source prompts and other users’ process details are not redistributed. Each arm has one successful run.
