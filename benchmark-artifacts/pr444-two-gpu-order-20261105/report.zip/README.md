# Two-GPU AgentX replay-order comparison

`REPORT.html` is self-contained. `aggregate.json` and `client/` contain sanitized worker and per-request/session metrics. The same trace and GPUs are used at both seeds; the replay order and other seed-derived inputs differ. Each arm is one run. Source prompts and other users’ process details are not redistributed.
