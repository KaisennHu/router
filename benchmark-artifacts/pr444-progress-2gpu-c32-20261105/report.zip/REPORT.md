## Performance: KV-aware with and without prefill progress

**Setup.** AgentInfer replays a selected AgentX subset: 32 sessions × 4 requests (128 requests; 4,620,928 input and 55,699 output tokens), C32, two colocated B300 workers, Qwen3-4B-Instruct-2507 BF16 TP1, 96 GiB GPU KV per worker, no CPU offload, max model length 196,608, max batched tokens 8,192, max 16 sequences per worker, and 64-token KV blocks.

Router `b2a1f411d5bb`, vLLM `cc009190cbbc`. Each arm ran once on the same GPUs after warmup and prefix-cache reset; Progress was run first. All 128 requests succeeded in each arm. The same-agent gap was scaled to zero and token IDs were reconstructed within each session; cross-session prefix sharing is not represented. Before each replay a repeated-prefix probe produced a Router placement-index hit; worker caches were then reset. This selected case and single-run comparison do not establish general or repeatable gains.

### 1. What does prefill progress change?

![Progress effect at C32](progress-effect.png)

The Router accepted 653 ordered progress frames during the replay, versus 0 with the switch off. Frames include initial unconfirmed queue snapshots, which do not update the ledger; their count is not the number of routing changes.

| Metric | KV → KV+P (relative change) |
| --- | ---: |
| Worker queue mean, ms | 955.64 → 912.68 (-4.50%) |
| Worker prefill mean, ms | 367.96 → 365.01 (-0.80%) |
| First-computed prompt tokens | 1,640,512 → 1,638,528 (-0.12%) |
| Iteration tokens (prefill + decode) | 1,696,211 → 1,694,227 (-0.12%) |
| Local prompt-cache hit rate | 64.50% → 64.54% (+0.04 pp) |
| Preemptions | 0 → 0 |

Queue is worker queued→scheduled; prefill is scheduled→first token and includes batch scheduling and contention. New prompt tokens are first-computed tokens, not FLOPs.

Mean TTFT for the 96 continuation requests changed from 850.36 to 780.02 ms; for the 32 first requests it changed from 2,951.29 to 2,963.05 ms. The overall TTFT mean decrease coincides mainly with a lower worker queue mean; prefill time and computed prompt tokens changed little. These observations alone do not prove that progress caused the differences.

### 2. End-to-end results

Changes are KV+P relative to KV. Lower latency and higher throughput are better.

| Metric | KV → KV+P (relative change) |
| --- | ---: |
| Input token/s | 66,008.66 → 66,407.47 (+0.60%) |
| Output token/s | 795.64 → 800.45 (+0.60%) |
| Total token/s | 66,804.31 → 67,207.93 (+0.60%) |
| TTFT mean, ms | 1,375.59 → 1,325.77 (-3.62%) |
| TPOT mean, ms/token | 38.28 → 38.57 (+0.76%) |
| Session JCT mean, s | 39.04 → 38.45 (-1.51%) |

**Distribution trade-offs:** TTFT P50 466.57 → 205.60 (-55.93%) ms; TPOT P95 137.24 → 139.45 (+1.61%) ms/token; session JCT P50 38.74 → 38.49 (-0.64%) s.

- **TTFT tails:** 60 → 65 requests finished TTFT within 250 ms, moving the median across that threshold; 1 → 2 exceeded 7 s. The slower tail requests are observable, but their scheduler-level cause was not traced.
- **TPOT mean:** 28 requests with 2–32 output tokens changed from 94.19 to 96.05 ms/token; their equal per-request weighting contributed to the mean change.
- **Session JCT:** mean summed TTFT per session was 5.50 s out of 39.04 s in KV, and 5.30 s out of 38.45 s in KV+P. The remaining session time includes decode and replay overhead.

Total throughput is logical input plus output tokens divided by replay wall time; it includes cached input. TPOT is per request `(latency − TTFT) / (output tokens − 1)`; requests with at most one output token are excluded (0 / 0). JCT is per session.

<details>
<summary>Latency distributions and worker details</summary>

| Metric | Mean | P50 | P95 | P99 |
| --- | --- | --- | --- | --- |
| TTFT, ms | 1,375.59 → 1,325.77 (-3.62%) | 466.57 → 205.60 (-55.93%) | 4,948.02 → 4,606.34 (-6.91%) | 6,418.64 → 7,095.99 (+10.55%) |
| TPOT, ms/token | 38.28 → 38.57 (+0.76%) | 21.31 → 21.67 (+1.72%) | 137.24 → 139.45 (+1.61%) | 143.68 → 144.78 (+0.76%) |
| Session JCT, s | 39.04 → 38.45 (-1.51%) | 38.74 → 38.49 (-0.64%) | 62.87 → 60.99 (-2.99%) | 68.12 → 66.98 (-1.68%) |

| Worker | Policy | Requests | Local hit % | Computed input | Queue / prefill mean ms | Waiting mean / P95 | Preemptions |
| --- | --- | ---: | ---: | ---: | --- | --- | ---: |
| 0 | KV | 62 | 62.93 | 872,448 | 1086.12 / 412.68 | 1.02 / 7.00 | 0 |
| 0 | KV+P | 67 | 64.03 | 815,296 | 900.11 / 346.31 | 0.94 / 8.00 | 0 |
| 1 | KV | 66 | 66.12 | 768,064 | 833.06 / 325.94 | 0.89 / 7.00 | 0 |
| 1 | KV+P | 61 | 65.03 | 823,232 | 926.48 / 385.55 | 0.85 / 7.00 | 0 |

Waiting is a time-weighted sampled worker queue length, not a per-request latency. P and D share colocated workers and cache; there is no P→D transfer to report.

</details>

No selected-GPU foreign process or KV-event decode/replay warning was observed. The host was shared: non-test GPUs had nonzero utilization in 68/68 KV samples and 44/69 KV+P samples; any host-level effect was not isolated. The worker used existing precompiled CUDA extensions and vendored runtime dependencies alongside the stated vLLM Python and Rust source.

The archive includes the two-arm request metrics and worker snapshots.
