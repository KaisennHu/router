# Mixed-serving Progress comparison

Goal: measure KV-aware with Progress off versus on using current Router #444 and vLLM #63160 PR heads. Both arms use the same preselected AgentX replay, configuration and GPUs. Record all results regardless of direction; do not compare other policies.

- AgentInfer, C32, 32 sessions × 4 original requests, 128 requests, 4,620,928 input and 55,699 output tokens; source tokens reconstructed within each session. Dataset is an intentionally selected overlap case and does not preserve cross-session token sharing.
- Two B300 workers, Qwen3-4B-Instruct-2507 BF16 TP1, 96 GiB GPU KV each, no host offload, max model length 196,608, max batched tokens 8,192, 16 maximum sequences per worker. Same-agent gaps scaled to zero. This is a two-worker result, not directly compared with the earlier four-worker data.
- Router `b2a1f411d5bb39f7a24d05b110ca06810d4b7ab5`; vLLM `cc009190cbbc62b9fdde64f64fdad2f2f95d7f58`. One successful run per arm; run Progress on first so its warmup can confirm accepted updates before replay, then the baseline.
- Configure Router KV event blocks as 64 tokens. Before either measured replay, use two identical prompts to verify that the Router's placement index records a hit, then reset all worker caches. Abort the run if the check fails.
- GPUs 2 and 3 are excluded by user request. A four-worker startup attempt on GPUs 0–3 was interrupted at the user's request and is not included in the comparison.
- The prior pair with 16-token Router blocks recorded only placement misses even though the workers reported cache hits; keep that pair as a separate diagnostic rather than using it as a validated benchmark.
- Restart and warm workers for each arm; reset prefix caches before the replay; monitor GPU ownership and host activity. Exclude a run only for a documented failed request, health or instrumentation error, or foreign process on a selected GPU.
- Compare input/output/total throughput; TTFT, TPOT and session JCT mean/P50/P95/P99; worker queue/prefill means, cache hits, computed prompt tokens, request counts and preemptions. Keep the latency and throughput regressions visible. Analyze logical token throughput separately from actual computed work.
