# KV event block-size preflight

A one-worker probe sent the same 1,024-token prompt twice to the same vLLM worker, with a cache reset between configurations. The worker used vLLM `cc009190cbbc`; the Router used `b2a1f411d5bb`.

| Router event block size | Router placement lookups | Result |
| --- | --- | --- |
| 16 | 2 misses | The repeated prefix did not match. |
| 64 | 1 miss, then 1 hit | The second lookup matched. |

The captured `BlockStored` events reported 64-token blocks. In the separate 16-block smoke, vLLM recorded 960 locally cached tokens for the repeated prompt despite the Router's misses.

The earlier C32 four-worker pair was configured with 16-token Router blocks and recorded only placement misses. Its performance figures are retained as diagnostics, not used as a validated KV-aware comparison. The new two-worker comparison configures 64-token blocks and requires a repeated-prefix Router hit before each measured replay.

The accompanying archive includes the captured event shapes and Router and worker metric snapshots under `raw/kv-index-smoke/`.
